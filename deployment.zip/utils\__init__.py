"""
Utility modules for DiddyMac agent system
"""

